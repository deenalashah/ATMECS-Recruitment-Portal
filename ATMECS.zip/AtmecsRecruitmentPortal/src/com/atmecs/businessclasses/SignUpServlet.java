package com.atmecs.businessclasses;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.atmecs.utilities.DatabaseConnection;



public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Connection connection= null;
	
	public void init() throws ServletException {
		
		connection=DatabaseConnection.getConnection();
		System.out.println(connection);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String email=request.getParameter("email");
		try{
		ResultSet rs=connection.createStatement().executeQuery("select * from signup where email="+"'"+email+"'");
		
		if(rs.next()){
			request.setAttribute("info", "User already registereed");
			request.getRequestDispatcher("signup.jsp").forward(request, response);
			System.out.println("In if");
		
		}
		else{
			String password=request.getParameter("password");
			String role="role_user";
			
				PreparedStatement preparedStatement=connection.prepareStatement("insert into signup values(?,?,?,?,?)");
				preparedStatement.setString(1, firstname);
				preparedStatement.setString(2, lastname);
				preparedStatement.setString(3, email);
				preparedStatement.setString(4, password);
				preparedStatement.setString(5, role);
				if(preparedStatement.executeUpdate()!=0)
				{
					request.setAttribute("info", "You have Successfully Registered! You can SignIn now");
					request.getRequestDispatcher("signup.jsp").forward(request, response);
					 
				}
				else
				{
					System.out.println("Some problem in registration");
				}
		}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		 
	}
	@Override
	public void destroy() {
		 DatabaseConnection.close();
	}

}
