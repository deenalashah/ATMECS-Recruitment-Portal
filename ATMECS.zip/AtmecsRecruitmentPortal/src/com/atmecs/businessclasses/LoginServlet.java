package com.atmecs.businessclasses;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.atmecs.utilities.DatabaseConnection;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String email=request.getParameter("email");
		
		String password=request.getParameter("password");
		Connection connection=DatabaseConnection.getConnection();
		  try {
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery("select * from signup where email='"+email+"' ");
			if(resultSet!=null){
				while(resultSet.next())
				{
					String first=resultSet.getString("firstname");
					String dbpassword=resultSet.getString("password");
					String role=resultSet.getString("role");
					if(dbpassword.equals(password)){
						HttpSession session = request.getSession();
						if(role.equals("employee")) {
							session.setAttribute("name", first);
							request.getRequestDispatcher("jobType.jsp").forward(request, response);
						}
						else {
							session.setAttribute("name", first);
							request.getRequestDispatcher("admin.jsp").forward(request, response);
						}
					}
				}
			} else {
				request.setAttribute("msg", "Email ID is noot registered.");
				request.getRequestDispatcher("signin.jsp").forward(request, response);
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
