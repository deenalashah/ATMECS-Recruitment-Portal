package com.atmecs.utilities;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

public class JobDescription {

	public JobDescription() {
		// TODO Auto-generated constructor stub
	}
	
	public void getFullDescription(){
		
		
	}
}
