package com.atmecs.utilities;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class JobInfo {

	public JobInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ArrayList getJobDetails(){
		
		Connection connection=DatabaseConnection.getConnection();
		  try {
			  Statement statement=connection.createStatement();
			  ResultSet resultSet=statement.executeQuery("select * from jobs");
			  ArrayList<Job_Pojo> listOfJobs=new ArrayList<Job_Pojo>();
			  while(resultSet.next()){
				  Job_Pojo jp=new Job_Pojo();
				  
				  jp.setJobId(resultSet.getInt(1));
				  jp.setJobTitle(resultSet.getString(2));
				  jp.setJobDesc(resultSet.getString(3));
				  jp.setSalary(resultSet.getInt(5));
				  listOfJobs.add(jp);
				  
			  }
			  
			 //listOfJobs.stream().forEach((i)->System.out.println(i));
			  
			  return listOfJobs;
			  
			}
		  catch(Exception e){
			  e.printStackTrace();
			  return null;
		  }
	}
}
