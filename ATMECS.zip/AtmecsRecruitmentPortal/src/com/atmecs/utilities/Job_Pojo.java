package com.atmecs.utilities;

public class Job_Pojo {
	
	private Integer jobId;
	private String jobTitle;
	private String jobDesc;
	private Integer salary;
	private String fullDescription;
	
	public Job_Pojo() {
		// TODO Auto-generated constructor stub
	}

	
	public Job_Pojo(Integer jobId, String jobTitle, String jobDesc, Integer salary, String fullDescription) {
		super();
		this.jobId = jobId;
		this.jobTitle = jobTitle;
		this.jobDesc = jobDesc;
		this.salary = salary;
		this.fullDescription = fullDescription;
	}



	public Integer getJobId() {
		return jobId;
	}

	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobDesc() {
		return jobDesc;
	}

	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public String getFullDescription() {
		return fullDescription;
	}

	public void setFullDescription(String fullDescription) {
		this.fullDescription = fullDescription;
	}

	

}
