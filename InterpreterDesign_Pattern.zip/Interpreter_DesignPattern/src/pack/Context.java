package pack;

import java.util.ArrayList;
import java.util.Date;

public class Context {

	private String expression;
	private Date date;
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public ArrayList<AbsttractExpression> getexpression_Order(Context context) {
		ArrayList<AbsttractExpression> expression_list=new ArrayList<AbsttractExpression>();
		String str_exp[]=context.getExpression().split("/");
		for(String str:str_exp)
		{
			if(str.equalsIgnoreCase("MM")){
				expression_list.add(new Month_Expression());
			}
			else if(str.equalsIgnoreCase("DD"))
			{
				expression_list.add(new DayExpression());
			}
			else{
				expression_list.add(new Year_Expression());
				
			}
		}
		return expression_list;
		
		
		
	}
	
}
