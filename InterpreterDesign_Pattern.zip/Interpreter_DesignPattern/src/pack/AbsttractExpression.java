package pack;

abstract public class AbsttractExpression {
	public abstract void evaluate(Context context);


}
