package pack;

import java.util.Date;

public class DayExpression extends AbsttractExpression{

	@Override
	public void evaluate(Context context) {
		String expression=context.getExpression();
		Date date=context.getDate();
		//System.out.println(date);
		Integer day= new Integer(date.getDate());
		//System.out.println(day);
		String temp_expression=expression.replaceAll("dd", day.toString());
		//System.out.println(temp_expression);
		context.setExpression(temp_expression);
		
	}
	
	

}
