package pack;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		System.out.println("Please select the date format : MM/DD/YYYY or DD/MM/YYYY");
		Scanner sc = new Scanner(System.in);
		String expression = sc.next();
		Date d=new Date();
		Context context = new Context();
		context.setExpression(expression);
		context.setDate(d);
		System.out.println("Input is - Format : " + expression + " Date :" + new Date());
		ArrayList<AbsttractExpression> expression_list = context.getexpression_Order(context);

		for (AbsttractExpression abstr_exp : expression_list) {
			abstr_exp.evaluate(context);
			System.out.println("  Evaluated Output :" + context.getExpression());

		}
		System.out.println("Output : " + context.getExpression());

	}

}
