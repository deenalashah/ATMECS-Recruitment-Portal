package pack;

import java.util.Date;

public class Month_Expression extends AbsttractExpression{

	@Override
	public void evaluate(Context context) {
		String expression=context.getExpression();
		Date date=context.getDate();
		Integer month= new Integer(date.getMonth()+1);
		String temp_expression=expression.replaceAll("mm", month.toString());
		//System.out.println(temp_expression);
		context.setExpression(temp_expression);
		
	}

}
