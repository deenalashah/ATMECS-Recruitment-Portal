package pack;

import java.util.Date;

public class Year_Expression extends AbsttractExpression {

	@Override
	public void evaluate(Context context) {
		String expression=context.getExpression();
		Date date=context.getDate();
		Integer year= new Integer(date.getYear()+1900);
		String temp_expression=expression.replaceAll("yyyy", year.toString());
		//System.out.println(temp_expression);
		context.setExpression(temp_expression);
		
	}

}
