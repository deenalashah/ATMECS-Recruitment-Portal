package com;

abstract public class AbstractExpression {
	
	abstract public int evaluate(Context context);

}
