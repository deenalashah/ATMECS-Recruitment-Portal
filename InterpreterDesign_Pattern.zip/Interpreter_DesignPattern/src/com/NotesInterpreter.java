package com;

import java.util.Scanner;

public class NotesInterpreter {

	public static void main(String[] args) {
	
		System.out.println("Enter the note");
		Scanner sc=new Scanner(System.in);
		String note=sc.next();
		Context context=new Context();
		context.setNote(note);
		context.setFrequency(0);
		System.out.println("The input note is "+note);
		FrequencyEvaluator freq_Eval=new FrequencyEvaluator();
		int final_Freq=freq_Eval.evaluate(context);
		System.out.println("The output frequency for the input note is "+final_Freq);
		
		

	}

}
