package com;

public class FrequencyEvaluator extends AbstractExpression {
	public int evaluate(Context context)
	
	{
		String note=context.getNote();
		int frequency=0;
		if(note.equals("sa"))
		{
			context.setFrequency(240);
			frequency=context.getFrequency();
		}
		else if(note.equals("re"))
		{
			context.setFrequency(270);
			frequency=context.getFrequency();
		}
		else if(note.equals("ga"))
		{
			context.setFrequency(300);
			frequency=context.getFrequency();
		}
		else if(note.equals("ma"))
		{
			context.setFrequency(320);
			frequency=context.getFrequency();
		}
		else
		{
			context.setFrequency(360);
			frequency=context.getFrequency();
		}
		return frequency;
		
	}
	
	

}
