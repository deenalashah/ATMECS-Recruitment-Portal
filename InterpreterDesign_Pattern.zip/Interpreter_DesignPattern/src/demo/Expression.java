package demo;

public interface Expression {
	
	public int interpret();

}
